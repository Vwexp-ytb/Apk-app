package com.example.opencam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.opencam.databinding.ActivityMainBinding
import com.google.android.material.chip.Chip
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private enum class Mode(val label: String, val ext: Int?) {
        PHOTO("Photo", null),
        HDR("HDR", ExtensionMode.HDR),
        NIGHT("Nuit", ExtensionMode.NIGHT),
        PORTRAIT("Portrait", ExtensionMode.BOKEH),
        BURST("Burst+", null)
    }

    private lateinit var b: ActivityMainBinding
    private val bgExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var extensions: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var busy = false

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else {
            Toast.makeText(this, "Permission caméra requise", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        Mode.values().forEach { m ->
            val chip = Chip(this).apply {
                text = m.label
                isCheckable = true
                isChecked = m == mode
                setOnClickListener { mode = m; bindCamera() }
            }
            b.modes.addView(chip)
        }
        b.flip.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            bindCamera()
        }
        b.shutter.setOnClickListener { if (!busy) capture() }
        b.ev.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) camera?.cameraControl?.setExposureCompensationIndex(p + evMin)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else permission.launch(Manifest.permission.CAMERA)
    }

    private var evMin = 0

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            val extFuture = ExtensionsManager.getInstanceAsync(this, provider!!)
            extFuture.addListener({
                extensions = extFuture.get()
                bindCamera()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bindCamera() {
        val p = provider ?: return
        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

        mode.ext?.let { ext ->
            val em = extensions
            if (em != null && em.isExtensionAvailable(selector, ext)) {
                selector = em.getExtensionEnabledCameraSelector(selector, ext)
            } else {
                toast("${mode.label} non supporté sur cet appareil")
                mode = Mode.PHOTO
                (b.modes.getChildAt(0) as Chip).isChecked = true
            }
        }

        val preview = Preview.Builder().build().also { it.setSurfaceProvider(b.preview.surfaceProvider) }
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(
                if (mode == Mode.BURST) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
            ).build()

        p.unbindAll()
        try {
            camera = p.bindToLifecycle(this, selector, preview, imageCapture)
        } catch (e: Exception) {
            toast("Erreur caméra : ${e.message}")
            return
        }

        val range = camera!!.cameraInfo.exposureState.exposureCompensationRange
        evMin = range.lower
        b.ev.max = range.upper - range.lower
        b.ev.progress = -evMin
        b.ev.isEnabled = range.upper != range.lower

        b.preview.setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                val point = b.preview.meteringPointFactory.createPoint(ev.x, ev.y)
                camera?.cameraControl?.startFocusAndMetering(
                    FocusMeteringAction.Builder(point).build()
                )
                v.performClick()
            }
            true
        }
    }

    private fun capture() {
        val ic = imageCapture ?: return
        busy = true
        if (mode == Mode.BURST) captureBurst(ic) else {
            val out = ImageCapture.OutputFileOptions.Builder(
                contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newValues()
            ).build()
            ic.takePicture(out, ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                        busy = false; toast("Photo enregistrée")
                    }
                    override fun onError(e: ImageCaptureException) {
                        busy = false; toast("Échec : ${e.message}")
                    }
                })
        }
    }

    private fun captureBurst(ic: ImageCapture, total: Int = 6) {
        val frames = mutableListOf<ByteArray>()
        var rotation = 0
        fun next() {
            status("Burst+ : ${frames.size + 1}/$total — ne bougez pas")
            ic.takePicture(bgExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val buf = image.planes[0].buffer
                    val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
                    if (frames.isEmpty()) rotation = image.imageInfo.rotationDegrees
                    image.close()
                    frames += bytes
                    if (frames.size < total) next() else process(frames, rotation)
                }
                override fun onError(e: ImageCaptureException) {
                    busy = false; status(null); toast("Échec : ${e.message}")
                }
            })
        }
        next()
    }

    private fun process(frames: List<ByteArray>, rotation: Int) {
        runOnUiThread { status("Fusion en cours…") }
        try {
            val bmp = StackProcessor.stack(frames, rotation)
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newValues())!!
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            bmp.recycle()
            runOnUiThread { toast("Burst+ enregistré") }
        } catch (e: Throwable) {
            runOnUiThread { toast("Fusion échouée : ${e.message}") }
        } finally {
            busy = false
            runOnUiThread { status(null) }
        }
    }

    private fun newValues() = ContentValues().apply {
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        put(MediaStore.Images.Media.DISPLAY_NAME, "OpenCam_$name.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OpenCam")
    }

    private fun status(text: String?) = runOnUiThread {
        b.status.text = text
        b.status.visibility = if (text == null) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    override fun onDestroy() { super.onDestroy(); bgExecutor.shutdown() }
}
