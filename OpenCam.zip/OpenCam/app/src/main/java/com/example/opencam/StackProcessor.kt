package com.example.opencam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import kotlin.math.abs
import kotlin.math.pow

/**
 * Fusion multi-images façon "HDR+ light" :
 * 1. décode chaque JPEG en demi-résolution (économie de mémoire)
 * 2. aligne chaque image sur la première (translation globale, recherche SAD)
 * 3. moyenne les pixels cohérents (rejette ceux qui bougent : anti-fantômes)
 * 4. applique une légère remontée des ombres + contraste
 */
object StackProcessor {

    private const val SAMPLE = 2          // 2 = moitié de la résolution
    private const val GRID = 4            // pas de la grille d'alignement
    private const val RANGE = 8           // décalage max testé (en cases de grille)
    private const val GHOST_THRESHOLD = 90

    fun stack(frames: List<ByteArray>, rotationDegrees: Int): Bitmap {
        val opts = BitmapFactory.Options().apply { inSampleSize = SAMPLE }
        val ref = BitmapFactory.decodeByteArray(frames[0], 0, frames[0].size, opts)
        val w = ref.width
        val h = ref.height
        val n = w * h

        val refPx = IntArray(n).also { ref.getPixels(it, 0, w, 0, 0, w, h) }
        ref.recycle()
        val refSmall = luma(refPx, w, h)

        val sumR = IntArray(n)
        val sumG = IntArray(n)
        val sumB = IntArray(n)
        val cnt = ByteArray(n)

        accumulate(refPx, refPx, w, h, 0, 0, sumR, sumG, sumB, cnt)

        for (i in 1 until frames.size) {
            val bmp = BitmapFactory.decodeByteArray(frames[i], 0, frames[i].size, opts) ?: continue
            if (bmp.width != w || bmp.height != h) { bmp.recycle(); continue }
            val px = IntArray(n).also { bmp.getPixels(it, 0, w, 0, 0, w, h) }
            bmp.recycle()
            val (dx, dy) = align(refSmall, luma(px, w, h), w / GRID, h / GRID)
            accumulate(refPx, px, w, h, dx * GRID, dy * GRID, sumR, sumG, sumB, cnt)
        }

        val lut = toneLut()
        val out = IntArray(n)
        for (i in 0 until n) {
            val c = cnt[i].toInt()
            val r = lut[sumR[i] / c]
            val g = lut[sumG[i] / c]
            val b = lut[sumB[i] / c]
            out[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        val result = Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        if (rotationDegrees == 0) return result
        val m = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
        return Bitmap.createBitmap(result, 0, 0, w, h, m, true).also { result.recycle() }
    }

    private fun luma(px: IntArray, w: Int, h: Int): IntArray {
        val sw = w / GRID
        val sh = h / GRID
        val out = IntArray(sw * sh)
        for (y in 0 until sh) for (x in 0 until sw) {
            val p = px[(y * GRID) * w + x * GRID]
            out[y * sw + x] = ((p shr 16 and 0xFF) * 77 + (p shr 8 and 0xFF) * 150 + (p and 0xFF) * 29) shr 8
        }
        return out
    }

    private fun align(ref: IntArray, cur: IntArray, sw: Int, sh: Int): Pair<Int, Int> {
        var best = Long.MAX_VALUE
        var bx = 0
        var by = 0
        for (dy in -RANGE..RANGE) for (dx in -RANGE..RANGE) {
            var sad = 0L
            var y = RANGE
            while (y < sh - RANGE) {
                var x = RANGE
                while (x < sw - RANGE) {
                    sad += abs(ref[y * sw + x] - cur[(y + dy) * sw + (x + dx)])
                    x += 2
                }
                y += 2
            }
            if (sad < best) { best = sad; bx = dx; by = dy }
        }
        return bx to by
    }

    private fun accumulate(
        ref: IntArray, cur: IntArray, w: Int, h: Int, dx: Int, dy: Int,
        sr: IntArray, sg: IntArray, sb: IntArray, cnt: ByteArray
    ) {
        val isRef = ref === cur
        for (y in 0 until h) {
            val sy = (y + dy).coerceIn(0, h - 1)
            for (x in 0 until w) {
                val sx = (x + dx).coerceIn(0, w - 1)
                val p = cur[sy * w + sx]
                val i = y * w + x
                val r = p shr 16 and 0xFF
                val g = p shr 8 and 0xFF
                val b = p and 0xFF
                if (!isRef) {
                    val q = ref[i]
                    val d = abs(r - (q shr 16 and 0xFF)) + abs(g - (q shr 8 and 0xFF)) + abs(b - (q and 0xFF))
                    if (d > GHOST_THRESHOLD) continue
                }
                sr[i] += r; sg[i] += g; sb[i] += b
                cnt[i]++
            }
        }
    }

    /** Courbe en S douce + ombres légèrement relevées. */
    private fun toneLut(): IntArray = IntArray(256) { v ->
        var x = v / 255.0
        x = x.pow(0.88)                                   // remonte les ombres
        x = x + 0.12 * (x - 0.5) * (1 - abs(2 * x - 1))   // contraste doux
        (x.coerceIn(0.0, 1.0) * 255).toInt()
    }
}
