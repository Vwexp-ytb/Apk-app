# OpenCam

Appli photo Android (Kotlin + CameraX), inspirée de GCam.

Modes : Photo, HDR / Nuit / Portrait (extensions constructeur, si supportées),
Burst+ (6 photos alignées et fusionnées, réduction du bruit).
Aussi : tap-to-focus, compensation d'exposition, caméra avant/arrière.

## Compiler
1. Ouvrir le dossier dans Android Studio (Koala ou plus récent), laisser Gradle synchroniser.
2. Brancher un téléphone (débogage USB) puis Run.
3. Pour un APK : Build > Build APK(s).

Photos enregistrées dans Pictures/OpenCam.
